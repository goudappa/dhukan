export interface Post {
    title: string;
}

// grouped posts by category
export interface GroupPosts {
    posts: Post[];
}