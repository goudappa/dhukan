
import { Address } from './address';

export class AddressServices {
    public data: Address;
}

