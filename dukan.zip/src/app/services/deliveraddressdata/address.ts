export class Address {
    firstName: string;
    lastName: string;
    contact: number;
    houseNum: any;
    apartmentName: any;
    street: any;
    landmark: any;
    city: any;
    area: any;
    pincode: number;
}