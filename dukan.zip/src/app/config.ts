export class AppSettings {
    //mainserverurl: http://192.169.243.70:5000/
    public static baseUrl = 'http://192.169.243.70:5000/';
    // public static baseUrl = 'http://192.169.243.70:8200/';
    public static imageUrl = 'http://versatilemobitech.co.in/DHUKAN/images/'
    // public static baseUrl = 'http://192.168.0.112:3000/';
    // public static baseUrl = 'http://192.168.0.130:3000/';
}

